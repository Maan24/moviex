<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h1>{{ $email['title'] }}</h1>
    <p>{{ $email['body'] }}</p>

    <p>Thank you</p>
</body>
</html>
