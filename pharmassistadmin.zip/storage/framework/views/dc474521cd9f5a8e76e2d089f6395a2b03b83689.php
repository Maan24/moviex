</main>
</div>
</div>

<!-- end side bar -->

<!-- bootstrap js file -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> -->


<script>
function goBack() {
    window.history.back();
};
$(document).ready(function() {
    $('.js-example-basic-multiple1').select2();
    $('.js-example-basic-multiple2').select2();
    $('.js-example-basic-multiple3').select2();
});
Fancybox.bind("[data-fancybox]", {
  // Your options go here
});
// $('.date').datepicker({
//     startDate: "now",
//     format: 'mm/dd/yyyy',
//     inline: true,
//     todayHighlight: true,
// });
// $(".shop-name").select2({
//     placeholder: "Select Shop Name",
//     allowClear: true
// });
// $(".sales-man-name").select2({
//     placeholder: "Select Sales Man",
//     allowClear: true
// });
// $(".products").select2({
//     placeholder: "Select Products",
//     allowClear: true
// });
</script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\thepharmassist\resources\views/Admin/Partials/footer.blade.php ENDPATH**/ ?>