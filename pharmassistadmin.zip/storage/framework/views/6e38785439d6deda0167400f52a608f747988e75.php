<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h1><?php echo e($email['title']); ?></h1>
    <p><?php echo e($email['body']); ?></p>

    <p>Thank you</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\thepharmassist\resources\views/CustomerEmails/forgotpass.blade.php ENDPATH**/ ?>