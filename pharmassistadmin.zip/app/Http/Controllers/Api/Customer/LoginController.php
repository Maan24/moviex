<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class LoginController extends Controller
{
    public function loginCustomer(Request $request){

        $validator = Validator::make($request->all(),[
            'email'=> 'required',
            'password' => 'required'
        ]);

        if($validator->fails()){
            return response()->json([
                'status' => false,
                'error' => $validator->errors()
            ]);
        }
        else{
            if(!Auth::attempt($request->only('email','password'))){
                return response()->json([
                    'status' => false,
                    'code' => 400,
                    'error' => 'The email or password you entered is incorrect'
                ]);
            }
            else{
                $user = Auth::user();
                return response()->json([
                    'status' => TRUE,
                    'message' => 'Login Successfully!',
                    'code' => 200,
                    'data' => $user
                ]);
            }
        }

    }
}

